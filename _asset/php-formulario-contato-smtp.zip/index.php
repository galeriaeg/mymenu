<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Envio de email autenticado</title>
</head>

<body>

<form action="email.php" method="post">

Nome:<br />
<input type="text" name="nome" maxlength="50" value="" />

<br /><br />

E-mail:<br />
<input type="text" name="email" maxlength="100" value="" />

<br /><br />

Telefone:<br />
<input type="text" name="telefone" maxlength="15" value="" />

<br /><br />

Celular:<br />
<input type="text" name="celular" maxlength="15" value="" />

<br /><br />

Cidade:<br />
<input type="text" name="cidade" maxlength="50" value="" />

<br /><br />

Mensagem:<br />
<textarea name="mensagem"></textarea>

<br /><br />

<button type="submit">ENVIAR</button>

</form>

</body>
</html>
